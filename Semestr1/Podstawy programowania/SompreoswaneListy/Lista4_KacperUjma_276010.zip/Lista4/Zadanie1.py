
for x in range(50):
    y=x+1
    wynik = y/100*100-y
    if wynik != 0:
        print(wynik,"dla wartosci rownej",y)