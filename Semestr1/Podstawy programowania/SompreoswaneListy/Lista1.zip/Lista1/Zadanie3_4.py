import math
def V(r):
    return ((4*math.pi*(r**3))/3)

print (V(5))
