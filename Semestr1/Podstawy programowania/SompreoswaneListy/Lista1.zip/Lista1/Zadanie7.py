Wiersz1 = ('  ____  ')
Wiersz2 = ('@/ ., \@')
Wiersz3 = ('( \__/ )')
Wiersz4 = (' \__U_/ ')
Tablica = [Wiersz1,Wiersz2,Wiersz3,Wiersz4]
for i in range (4):
    print (Tablica[i])